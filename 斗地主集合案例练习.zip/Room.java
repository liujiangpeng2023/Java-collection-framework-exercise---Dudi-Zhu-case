package 集合.斗地主集合案例练习;

import java.util.*;

public class Room {
    private List<Card> allCards = new ArrayList<>();
    public Room() {
        String[] numbers = {"3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "k", "A", "2"};
        String [] Colors={"♠","♦","♥","♣"};
        int size = 0;
        for (String number : numbers) {
            size++;
            for (String color : Colors) {
                Card card =new Card(number, color,size);
                allCards.add(card);
            }
        }
        Card c1=new Card("","小王",++size);
        Card c2=new Card("","大王",++size);
        Collections.addAll(allCards,c1,c2);
        System.out.println(allCards);
    }
//游戏启动
    public void start() {
        List<Card> liujiangpeng=new ArrayList<>();
        List<Card> liubaiqi=new ArrayList<>();
        List<Card> liujiajun=new ArrayList<>();

        //洗牌
        Collections.shuffle(allCards);
        //发牌 三个玩家用三个arrylist
        give_Cards(allCards,liujiangpeng,liujiajun,liubaiqi);
        //选地主
        choose_landOener(allCards,liujiangpeng,liujiajun,liubaiqi);
        //看牌
        lookCards(liujiangpeng,liujiajun,liubaiqi);
    }
    public void give_Cards(List<Card> allCards,List<Card> liujiangpeng,List<Card> liujiajun ,List<Card> liubaiqi)
    {
         for (int i = 0; i < allCards.size()-3; i++) {
             System.out.println("正在发第"+(i+1)+"张牌");
            if (i%3==0)
            {
                liujiangpeng.add(allCards.get(i));
            }
            else if (i%3==1)
            {
                liubaiqi.add(allCards.get(i));
            }
            else if (i%3==2)
            {
                liujiajun.add(allCards.get(i));
            }
        }
    }
    public void choose_landOener(List<Card> allCards,List<Card> liujiangpeng,List<Card> liujiajun ,List<Card> liubaiqi)
    {
        List<Card> lastCards = allCards.subList(allCards.size()-3,allCards.size());//截取最后三张牌
        System.out.println("底牌"+lastCards);
        Random random = new Random();
        System.out.println("分配地主：");
        int flag= random.nextInt(3);

        if (flag==1)
        {
            System.out.println("地主为刘江鹏");
            liujiangpeng.addAll(lastCards);
        } else if (flag==2) {
            System.out.println("地主为刘柏齐");
            liubaiqi.addAll(lastCards);
        } else if (flag==0) {
            System.out.println("地主为刘嘉俊");
            liujiajun.addAll(lastCards);
        }

    }



    public void lookCards(List<Card> liujiangpeng,List<Card> liujiajun ,List<Card> liubaiqi)
    {
        sortCards(liujiangpeng);
        System.out.println("刘江鹏的牌"+liujiangpeng+"有"+liujiangpeng.size()+"张牌");
        sortCards(liujiajun);
        System.out.println("刘嘉俊的牌"+liujiajun+"有"+liujiajun.size()+"张牌");
        sortCards(liubaiqi);
        System.out.println("刘柏齐的牌"+liubaiqi+"有"+liubaiqi.size()+"张牌");
    }
    public void sortCards(List<Card> list)
    {
        Collections.sort(list, (o1, o2) -> o1.getSize()-o2.getSize());
    }
}
