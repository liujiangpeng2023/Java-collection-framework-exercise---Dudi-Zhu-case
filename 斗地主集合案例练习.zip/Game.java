package 集合.斗地主集合案例练习;

public class Game {
    public static void main(String[] args) {
        Room room = new Room();
        room.start();
    }
}

